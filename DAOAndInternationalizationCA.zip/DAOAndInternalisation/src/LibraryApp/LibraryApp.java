/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LibraryApp;

import business.Book;
import business.Loan;
import daos.BookDao;
import daos.LoanDao;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.Scanner;
import utils.FileHandlingUtilities;

/**
 *
 * @author melanie uamai
 */
public class LibraryApp {
    /**
     * setting up variables that may be needed across me4thods
     * Scanner interact with user
     * internationalisation
     * Book data access object info methods
     */
    private static Scanner keyboard = new Scanner(System.in);
    private static ArrayList<Book>books = new ArrayList();
    private static ArrayList<Loan>Loans = new ArrayList();
    //all methods can pull properties from the rb bundle
    private static ResourceBundle rb;
    //locale is available to all other methods once made static and private
    private static Locale currentLocale;
    private static BookDao bk = new BookDao("library");
    private static LoanDao lb = new LoanDao("library");
    
    
    public static void main(String[] args){
        //INTERNATIONALISATION components
        //ALSO TRANSLATED IN FRENCH
        currentLocale = new Locale("en", "GB");
        System.out.println("Current Language setting: " + currentLocale.getDisplayLanguage());
        //resource bundle to access all components of the application
        rb = ResourceBundle.getBundle("languages.BookApp", currentLocale);
        //set up book class locale 
        Book.updateLocale(currentLocale);
        FileHandlingUtilities.updateLocale(currentLocale);
        // Proceed with program
        // Set the Scanner to use \n (new line) as the delimiter within text.
        // This means that even if you use .next(), it will read to the end of the line
        // NOT just to the end of the word 
        keyboard.useDelimiter("\n");
        
        
        System.out.println(rb.getString("main_greeting"));
        System.out.println("*****************************");
        
        //String books = displayMenu();
       
        boolean continueRunning = true;
        while(continueRunning){
            //show user choices
            int choice = displayMenuAndChoices();
            switch(choice){
                //Exit system
                case 0:
                    System.out.println(rb.getString("main_farewell"));
                 break;
                 //View All Books
                case 1:
                    viewAllBooks();
                    break;
                 //view books by title
                case 2:
                   viewBookByTitle();
                   break;
                case 3:
                    addBooks();
                    break;
                    //borrow book
                case 4:
                    borrowBooks();
                    break;
                case 5:
                    returnBooks();
                    break;
                case 6:
                     ViewAllLoans();
                     break;
                case 7:
                     ViewActiveLoan();
                     break;
                case 8: 
                      viewPreviousLoan();
                    break;
                default:
                    //user enters wrong number
                    System.out.println("main_invalidOption");
            }
        }
        System.out.println(rb.getString("main_farewell"));
    }
    public static int displayMenuAndChoices(){
        System.out.println(rb.getString("displayMenuAndChoices_prompt"));
        System.out.println(rb.getString("displayMenuAndChoices_exitChoice"));
        System.out.println(rb.getString("displayMenuAndChoices_ViewAllBooks"));
        System.out.println(rb.getString("displayMenuAndChoices_ViewBookByTitle"));
        System.out.println(rb.getString("displayMenuAndChoices_AddBook"));
        System.out.println(rb.getString("displayMenuAndChoices_BorrowBook"));
        System.out.println(rb.getString("displayMenuAndChoices_ReturnBook"));
        System.out.println(rb.getString("displayMenuAndChoices_getAllActiveLoans"));
        System.out.println(rb.getString("displayMenuAndChoices_detailsOfPreviousLoans"));
        System.out.println(rb.getString("displayMenuAndChoices_getAllLoans"));
        return getChoice(0,10);
    }
    
    public static int getChoice(int min, int max){
        //Request menu option selection from user
        System.out.println(rb.getString("chooseOption_prompt"));
        int choice = keyboard.nextInt();
        //while its currently not within range, user will be asked 
        //to choose a number between 0 and 5
        while(choice < min && choice > max){
            //user needs to enter a valid option
            System.out.printf(rb.getString("chooseOption_warning"), min , max);
            //take in a value actually in the menu
            choice = keyboard.nextInt();
        } keyboard.nextLine();
        return choice;
    }
    
    //view all books
    public static void viewAllBooks(){
        System.out.println(rb.getString("viewAllBooks_displayBooks"));
        System.out.println("viewAllBooks_displayDivide");
        
        for(Book b : books){
            System.out.println(b.toString());
        }
        
        System.out.println(rb.getString("viewAllBooks_displayDivide"));
        
    }
    
    public static void viewBookByTitle(){
        System.out.println(rb.getString("viewBookByTitle_insertTitle"));
        //clear scanner, because it gets stuck with an empty value
        //keyboard.nextLine();
        String title = keyboard.nextLine();
        
        Book b = bk.getBookByTitle(title);
        if(b != null){
            System.out.println(rb.getString("viewBookbyTitle_displayBook"));
            System.out.println(b);
        }else{
            System.out.println(rb.getString("viewBookByTitle_bookNotFound"));
        }
    }
    
    public static void addBooks(){
        System.out.println("please enter the following information:");
        System.out.println("***************************************");
        
        bk = new BookDao("library");
        
        System.out.println(rb.getString("populateLibrary_insertTitle"));
        String title = keyboard.nextLine();
        System.out.println(rb.getString("populateLibrary_insertAuthor"));
        String author = keyboard.nextLine();
        System.out.println(rb.getString("populateLibrary_insertYrPublished"));
        String yrPublished = keyboard.nextLine();
        System.out.println(rb.getString("populateLibrary_insertAmount"));
        int stock = keyboard.nextInt();
        System.out.println(rb.getString("populateLibrary_insertCode"));
        int bookCode = keyboard.nextInt();
        
        boolean added = bk.addBook(bookCode,title,author,yrPublished,stock);
        if(added == false){
            System.out.println(rb.getString("populateLibrary_BookNotAdded"));
        }else{
            System.out.println(rb.getString("populateLibrary_BookAdded") + title);
        }
    }
    
    public static void borrowBooks(){
        System.out.println("please enter the following information:");
        System.out.println("***************************************");
        
        System.out.println(rb.getString("borrowBookChoice_insertTitle"));
        String title = keyboard.nextLine();
        System.out.println(rb.getString("borrowBookChoice_insertAuthor"));
        String author = keyboard.nextLine();
        System.out.println(rb.getString("borrowBookChoice_insertUserId"));
        int userId = keyboard.nextInt();
        
        int successful = bk.borrowBook(title, author, userId);
        
        if(successful > 0){
            System.out.println(rb.getString("borrowBookChoice_success") + title);
            System.out.println("Book details: ");
            System.out.println(title);
        }else{
            System.out.println(rb.getString("borrowBookChoice_failure"));
        }
    }
    
    public static void returnBooks(){
        System.out.println("please enter the following information: ");
        System.out.println("****************************************");
        
        System.out.println(rb.getString("returnBookChoice_insertTitle"));
        String title = keyboard.nextLine();
        System.out.println(rb.getString("returnBookChoice_insertAuthor"));
        String author = keyboard.nextLine();
        System.out.println(rb.getString("returnBookChoice_insertUserId"));
        int userId = keyboard.nextInt();
        System.out.println("Status: ");
        
        int successful = bk.returnBook(title, author, userId);
        
        if(successful < 0){
            System.out.println(rb.getString("returnBookChoice_success"));
            System.out.println("Returned: ");
            System.out.println(title);
        }else{
            System.out.println(rb.getString(""));
        }
    }
        //view all loans
    public static void ViewAllLoans(){
        System.out.println(rb.getString("viewAllLoans_displayLoans"));
        System.out.println("viewAllLoans_displayDivide");
         List<Loan> b = lb.getAllLoans();
        if(b != null){
            System.out.println(rb.getString("viewAllLoans_displayLoans"));
            System.out.println(b);
        }else{
            System.out.println(rb.getString("viewAllLoans_LoanNotFound"));
        }
    }
    
     public static void ViewActiveLoan(){
        System.out.println(rb.getString("viewActiveLoan_insertUserID"));
        //clear scanner, because it gets stuck with an empty value
        //keyboard.nextLine();
        int userID = keyboard.nextInt();
        
        List<Loan> b = lb.getAllActiveLoans(userID);
        if(b != null){
            System.out.println(rb.getString("viewActiveLoan_displayLoan"));
            System.out.println(b);
        }else{
            System.out.println(rb.getString("viewActiveLoan_LoanNotFound"));
        }
    }
     
      public static void viewPreviousLoan(){
        System.out.println(rb.getString("viewPreviousLoan_insertUserID"));
        //clear scanner, because it gets stuck with an empty value
        //keyboard.nextLine();
        int userID = keyboard.nextInt();
        
        Loan b = (Loan) lb.detailsOfAllPreviousLoans(userID);
        if(b != null){
            System.out.println(rb.getString("viewPreviousLoan_displayLoan"));
            System.out.println(b);
        }else{
            System.out.println(rb.getString("viewPreviousLoan_LoanNotFound"));
        }
    }
}
