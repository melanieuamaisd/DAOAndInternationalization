/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package WithDao;

import business.Book;
import daos.BookDao;

import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.Scanner;

/**
 *
 * @author MELANIE WHO-AM-I
 */
public class ExampleWithDao {
    private static Locale tempLocale;
    public static void main(String[] args){
        //where user is known to be from
        tempLocale = new Locale("en","ie");
        //where you will find transaltions
       ResourceBundle bundle = ResourceBundle.getBundle("languages.BookApp_en", tempLocale);
        System.out.println("This program selects a book and all of its details");
        System.out.println("The user can then enter a specific title");
        System.out.println("+++++++++++++++++++++++++++++++++++++++++++++++++++");
        
        Scanner keyboard = new Scanner(System.in);
        //member can view all books
        BookDao bDao = new BookDao("library");
        List<Book> books = bDao.getAllBooks();
        
        for(Book b : books){
            System.out.println("Book id= " + b.getId() + "- Book Title: " + b.getTitle());
        }
        System.out.println("************************************************************");
        System.out.println("Enter a title to see its full details");
        String book = keyboard.nextLine();
        
        Book b = bDao.getBookByTitle(book);
        if(b != null){
            System.out.println("Book details: ");
            System.out.println(b);
        } else{
            System.out.println("No results found for that book.");
        }
       // System.out.println("************ADD A BOOK****************");
    
        //ADD BOOK
         
         System.out.println("please enter the title of the book you would like to add");
         String newBook = keyboard.nextLine();
         System.out.println("please enter the author");
         String newAuthor = keyboard.nextLine();
         System.out.println("please enter the year it was published");
         String published = keyboard.nextLine();
         System.out.println("please enter the amount you would like to add");
         int stock = keyboard.nextInt();
         System.out.println("please enter a code for the book");
         int bookCode = keyboard.nextInt();
         
         //INSERT QUERY
        boolean added = bDao.addBook(bookCode,newBook, newAuthor, published, stock);
        
        if(added == false){
            System.out.println("Book not added");
         }else{
            
            System.out.println("Book successfully added" +" " + newBook);
        }
         
         
        //BORROW BOOK METHOD
        
       System.out.println("please enter the book you would like to borrow");
        String bookTitle = keyboard.nextLine();
        
        System.out.println("please enter the author");
        String author = keyboard.nextLine();
        
        System.out.println("Please enter user id");
        int userId = keyboard.nextInt();
        
        //user id hard coded as 1
        //USER ID HAS TO BE 1012 OR ABOVE
        int successful = bDao.borrowBook(bookTitle, author, userId);
        
        if(successful > 0){
            System.out.println("You have successfully borrowed: " + bookTitle);
            System.out.println("Book Details");
            System.out.println(b);
        }
        else{
            System.out.println("Book is already borrowed");
        }
        //RETURN BOOK
        System.out.println("Title of book you would like to return: ");
        String title = keyboard.nextLine();
        
        System.out.println("Author: ");
        String bAuthor = keyboard.nextLine();
        
        System.out.println("User ID: ");
        int Id = keyboard.nextInt();
        
        int success = bDao.returnBook(title, author, userId);
         if(successful < 0){
            System.out.println("You have successfully returned: " + bookTitle);
            System.out.println("*****************************************");
            System.out.println(b);
        }
        else{
            System.out.println("Book is already returned");
        }
         
    }
}
