/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package utils;

import business.Book;
import business.Loan;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author MELANIE WHO-AM-I
 */
public class FileHandlingUtilities {
      private static Locale locale = Locale.getDefault();
      private static ResourceBundle bundle = ResourceBundle.getBundle("languages.FileHandlinUtilities_en", locale);
    
    
     // Reset the resource bundle being used within the FileHandlingUtilities methods
    // so that it uses the right language file
    private static void updateBundle(){
        bundle = ResourceBundle.getBundle("languages.FileHandlinUtilities_en", locale);
    }
    
      // If the locale the program is to be run under is changed
    // E.g. if the user changes their preference
    // then we need to update it here 
    // AND trigger the resource bundle to be updated
    public static void updateLocale(Locale l){
        locale = l;
        updateBundle();
    }
    
    public static ArrayList<Book> readBooksFile(String filename){
        ArrayList<Book> books = new ArrayList();
        
        Scanner inputFile;
        try{
            inputFile = new Scanner(new FileReader(filename));
            while(inputFile.hasNextLine()){
                String currentLine = inputFile.nextLine();
                String[] data = currentLine.split(Book.BREAKING_CHAR);
                try{
                    int id = Integer.parseInt(data[0]);
                    String title = data[1];
                    String author = data[2];
                    int published = Integer.parseInt(data[3]);
                    int stock = Integer.parseInt(data[4]);
                }catch(NumberFormatException | ArrayIndexOutOfBoundsException e){
                    System.out.println(bundle.getString("readBooksFile_corruptLine") + currentLine);
                    System.out.println(bundle.getString("readBooksFile_skip"));
            }
          }
        }catch (FileNotFoundException ex){
            Logger.getLogger(FileHandlingUtilities.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println(bundle.getString("readBooksFile_exception") + ex.getMessage());
    }
        return books;
    }
     public static ArrayList<Loan> readLoansFile(String filename){
        ArrayList<Loan> loans = new ArrayList();
        
        Scanner inputFile;
        try{
            inputFile = new Scanner(new FileReader(filename));
            while(inputFile.hasNextLine()){
                String currentLine = inputFile.nextLine();
                String[] data = currentLine.split(Loan.BREAKING_CHAR);
                try{
                    int loanID = Integer.parseInt(data[0]);
                    int userID = Integer.parseInt(data[0]);
                    int bookID = Integer.parseInt(data[0]);
                    String loan_Date = data[1];
                    String due_date = data[2];
                    String status = data[3];
                   
                    
                }catch(NumberFormatException | ArrayIndexOutOfBoundsException e){
                    System.out.println(bundle.getString("readLoansFile_corruptLine") + currentLine);
                    System.out.println(bundle.getString("readLoansFile_skip"));
            }
          }
        }catch (FileNotFoundException ex){
            Logger.getLogger(FileHandlingUtilities.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println(bundle.getString("readLoansFile_exception") + ex.getMessage());
    }
        return loans;
    }
     
   public static boolean writeBooksFile(String filename, ArrayList<Book> books){
        boolean cleanWrite = true;
        try {
            PrintWriter output = new PrintWriter(new FileWriter(filename));
            
            for(Book b : books){
                output.println(b.formatForStorage());
                output.flush();
            }
            
            output.close();
        } catch (IOException ex) {
            Logger.getLogger(FileHandlingUtilities.class.getName()).log(Level.SEVERE, null, ex);
            System.out.printf(bundle.getString("writeBooksFile_exception"), filename);
            System.out.println(bundle.getString("writeBooksFile_exceptionText") + ex.getMessage());
            cleanWrite = false;
        }
        
        return cleanWrite;
    }
   
    public static boolean writeLoansFile(String filename, ArrayList<Loan> loans){
        boolean cleanWrite = true;
        try {
            PrintWriter output = new PrintWriter(new FileWriter(filename));
            
            for(Loan l : loans){
                output.println(l.formatForStorage());
                output.flush();
            }
            
            output.close();
        } catch (IOException ex) {
            Logger.getLogger(FileHandlingUtilities.class.getName()).log(Level.SEVERE, null, ex);
            System.out.printf(bundle.getString("writeLoansFile_exception"), filename);
            System.out.println(bundle.getString("writeLoansFile_exceptionText") + ex.getMessage());
            cleanWrite = false;
        }
        
        return cleanWrite;
    }
    }

