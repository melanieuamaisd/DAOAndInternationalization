/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package daos;

import business.Book;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 *
 * @author melanie uamai
 */
public class BookDao extends Dao implements BookDaoInterface{
     /**
     * Initialises a BookDao to access the specified database name
     * 
     * @param databaseName The name of the MySQL database to be accessed (this database should 
     * be running on localhost and listening on port 3306).
     */
    public BookDao(String databaseName) {
        super(databaseName);
    }
   /**
   * 
   * @return 
   */
    @Override
    public List<Book> getAllBooks() {
        
            Connection conn = null;
            PreparedStatement ps = null;
            ResultSet rs = null;
            List<Book> books = new ArrayList();
            
            try{
            conn = getConnection();
            //viewing the details of all books in the library
            String query = "SELECT * FROM books";
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();
            
            while(rs.next())
            {
                Book b = new Book(rs.getInt("bookID"), rs.getString("title"), rs.getString("author"), rs.getInt("published"), rs.getInt("stock"));
                books.add(b);
            }
        } catch (SQLException ex) {
           System.out.println("Exception occured in getAllBooks() method" + ex.getMessage());
        } finally {
            try{
                if(rs != null){
                    rs.close();
                }
                if(ps != null){
                    ps.close();
                }
                if(conn != null){
                    freeConnection(conn);
                }
            }catch(SQLException e){
                System.out.println("Exception occure in the finally section" + e.getMessage());
            }
         }
        return books;
    }
    /**
     * 
     * @param title
     * @return 
     */
    @Override
    public Book getBookByTitle(String title) {
       
            Connection conn = null;
            PreparedStatement ps = null;
            ResultSet rs = null;
            Book b = null;
            try{
            conn = getConnection();
            
            String query = "SELECT * FROM books WHERE title = ?";
            ps = conn.prepareStatement(query);
            ps.setString(1, title);
            rs = ps.executeQuery();
            
            if(rs.next())
            {
                 b = new Book(rs.getInt("bookID"), rs.getString("title"), rs.getString("author"), rs.getInt("published"), rs.getInt("stock"));
            }
        } catch (SQLException ex) {
           System.out.println("An exception occured in the getBookByTitle() method" + ex.getMessage());
        } finally{
                try{
                if(rs != null){
                    rs.close();
                }
                if(ps != null){
                    ps.close();
                }
                if(conn != null){
                    freeConnection(conn);
                }
              } catch(SQLException ex){
                   System.out.println("Exception occured in the finally section of the getBookByTitle() method: " + ex.getMessage());
              }
            }
            return  b;
        }
    /**
     * 
     * @param bookID
     * @param title
     * @param author
     * @param published
     * @param stock
     * @return 
     */
    @Override
    public boolean addBook(int bookID, String title, String author, String published, int stock ) {
       Connection conn = null;
       PreparedStatement ps = null;
       ResultSet rs = null;
       int result = 0;
       boolean insert = false;
       
       
       try{
           conn = getConnection();
           String query = "INSERT INTO books (bookID, title, author, published, stock)" + "VALUES(?,?,?,?,?)";
           ps = conn.prepareStatement(query);
           ps.setInt(1, bookID);
           ps.setString(2, title);
           ps.setString(3, author);
           ps.setString(4, published);
           ps.setInt(5, stock);
           if(ps.executeUpdate() > 0){
               insert = true;
           }
       }catch(SQLException ex){
           System.out.println("An error occured in the add book method" + ex.getMessage());
       }finally {
            try {
                
                if (ps != null) {
                    ps.close();
                }
                if (conn != null) {
                    freeConnection(conn);
                }
            } catch (SQLException e) {
                System.out.println("Exception occured in the finally section method: " + e.getMessage());
            }
          }
       return insert;
    }
    /**
     * 
     * @param title
     * @param author
     * @param userId
     * @return 
     */
    @Override
    public int borrowBook(String title, String author, int userId) {
       Connection conn = null;
       PreparedStatement ps = null;
       ResultSet rs = null;
       int result = 0;
       
       
       try{
       conn = getConnection();
       String query = "SELECT stock, bookID FROM books WHERE title=?  AND author=?";
       ps = conn.prepareStatement(query);
       ps.setString(1, title);
       ps.setString(2, author);
       //to make sure its working
       System.out.println("Borrowing");
               
               
       rs = ps.executeQuery();
       rs.next();
       //quantity
       int stock = rs.getInt(1);
       int bookId = rs.getInt(2);
       //create instance of loanDao
       System.out.println(stock);
       if (stock > 0){
           //date 
           LocalDate date = LocalDate.now();
           String dateBorrowed = date.toString();
           String dateDue = date.plusDays(14).toString();
           System.out.println(dateDue);
           System.out.println(dateBorrowed);
           query = "INSERT INTO loan (userID,  bookID,  loan_Date,  due_date, status) VALUES (" 
                   + userId + "," + bookId + ",'" + dateBorrowed + "','" + dateDue + "', 'active')";  
           ps = conn.prepareStatement(query);
           //execute update
           result = ps.executeUpdate();
       }//else book not found / out of stocks
       else{
           System.out.println("book not found");
       }
    }catch(SQLException ex){
        System.out.println("An error occured in borrowBook() method" + ex.getMessage());
    }finally {
            try {
                
                if (ps != null) {
                    ps.close();
                }
                if (conn != null) {
                    freeConnection(conn);
                }
            } catch (SQLException e) {
                System.out.println("Exception occured in the finally section method: " + e.getMessage());
            }
          }
          return result;
    }

    
    /**
     * 
     * @param title
     * @param author
     * @param userId
     * @param status
     * @return 
     * 
     * check whether user has borrowed book and status is active with a SELECT query
     * if status == active this means the user has borrowed a book 
     * return / execute query
     * UPDATE loan status to 'closed' and UPDATE book stock + 1;
     */
    @Override
    public int returnBook(String title, String author, int userId) {
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        int result = 0;
        
        try{
        conn = getConnection();
        String query = "SELECT stock, bookID FROM books WHERE title=? AND author=?";
        ps = conn.prepareStatement(query);
        ps.setString(1, title);
        ps.setString(2, author);
       
        System.out.println("Returning: ");
        rs = ps.executeQuery();
        //if there is no next line in result set (empty)
        if(!rs.next()){
             System.out.println("Book does not exist");
             return result;
        }
        //quantity
        int stock = rs.getInt(1);
        //we know bookId from previous query
        int bookId = rs.getInt(2);
        //String status = rs.getString(3);
        //check whether user has borrowed book and status is active
         query = "SELECT * FROM loan WHERE bookID= " + bookId + " AND userID= " + userId;
         ps = conn.prepareStatement(query);
         rs = ps.executeQuery();
         if(rs.next()){
             //a loan exists and can be changed
         
        //if else , if ! null, this means a user has borrowed the book else return / execute query
       //if needed to be returned , UPDATE loan status 'closed' and UPDATE book stock + 1;
        System.out.println();
      
            //date 
            LocalDate date = LocalDate.now();
            String dateReturned = date.toString();
            System.out.println(dateReturned);
            //UPDATING , compound key
            query = "UPDATE loan SET status ='closed' WHERE bookID= " + bookId + " AND userID= " + userId; 
            ps = conn.prepareStatement(query);
            //execute update
            result = ps.executeUpdate();
            if(result > 0){
                System.out.println("Book was successfully returned");
            }else{
                System.out.println("Error occured in the return method");
            }
        }else{
            System.out.println("Loan does not exist");
      }
        } catch (SQLException ex) {
           System.out.println("An error occured in the returnBook method()" + ex.getMessage());
        }finally{
             try {
                
                if (ps != null) {
                    ps.close();
                }
                if (conn != null) {
                    freeConnection(conn);
                }
            } catch (SQLException e) {
                System.out.println("Exception occured in the finally section method: " + e.getMessage());
            }
          }
          return result;
        }
   }
 
   
     
    
    

