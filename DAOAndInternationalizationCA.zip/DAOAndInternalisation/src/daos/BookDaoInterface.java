/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package daos;

import business.Book;
import java.util.List;

/**
 *
 * @author MELANIE WHO-AM-I
 */
public interface BookDaoInterface {
    
    public List<Book> getAllBooks();
    public Book getBookByTitle(String title);
    public boolean addBook(int bookID,String title, String author, String published, int stock );
    public int borrowBook (String title , String author, int userId);
    public int returnBook(String title, String author, int userId);
}
