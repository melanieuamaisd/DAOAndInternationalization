/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package daos;

import business.Loan;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Waseema
 */
public class LoanDao extends Dao implements LoanDaoInterface {
/**
     * Initialises a ProductDao to access the specified database name
     * 
     * @param databaseName The name of the MySQL database to be accessed (this database should 
     * be running on localhost and listening on port 3306).
     */

 
    public LoanDao(String databaseName) {
        super(databaseName);
    }

    @Override
    public List<Loan> getAllLoans() {
         Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null; 
        List<Loan> loans = new ArrayList();
        
        try{
            con = getConnection();

 

            String query = "Select * from loan";
           
            ps = con.prepareStatement(query);
            rs = ps.executeQuery(); 
            
            while(rs.next())
            {
                Loan p = new Loan(rs.getInt("loanID"),rs.getInt("userID"), rs.getInt("bookID"), rs.getString("loan_Date"), rs.getString("due_date"), rs.getString("status"));
                loans.add(p);
            }
        }catch (SQLException e) {
            System.out.println("Exception occured in the getAllLoans() method: " + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException e) {
                System.out.println("Exception occured in the finally section of the getAllLoans() method: " + e.getMessage());
            }
        }
        
        return loans;
    }

    @Override
    public List<Loan> detailsOfAllPreviousLoans(int userId) {
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<Loan> loans = new ArrayList();
         try{
            con = getConnection();

 

            String query = "Select * from loan where userID = ? AND status = 'closed' ";
            ps = con.prepareStatement(query);
            ps.setInt(1, userId);
            rs = ps.executeQuery(); 
            
            while(rs.next())
            {
               Loan p = new Loan(rs.getInt("loanID"),rs.getInt("userID"), rs.getInt("bookID"), rs.getString("loan_date"), rs.getString("due_date"), rs.getString("status"));
                loans.add(p);
            }
        }catch (SQLException e) {
            System.out.println("Exception occured in the getAllActiveLoans() method: " + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException e) {
                System.out.println("Exception occured in the finally section of the getAllActiveLoans() method: " + e.getMessage());
            }
        }
        
        return  loans;
    }

    @Override
    public List<Loan> getAllActiveLoans(int userID) {
         Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<Loan> loan = new ArrayList();
        
        try{
            con = getConnection();

 

            String query = "Select * from loan where userID = ? AND status = 'active'";
            ps = con.prepareStatement(query);
            ps.setInt(1, userID);
            rs = ps.executeQuery(); 
            
            while(rs.next())
            {
               Loan p = new Loan(rs.getInt("loanID"),rs.getInt("userID"), rs.getInt("bookID"), rs.getString("loan_date"), rs.getString("due_date"), rs.getString("status"));
                loan.add(p);
                  }
        }catch (SQLException e) {
            System.out.println("Exception occured in the getAllActiveLoans() method: " + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException e) {
                System.out.println("Exception occured in the finally section of the getAllActiveLoans() method: " + e.getMessage());
            }
        }
        
        return loan;
        
    }

   

    

    
    
}
