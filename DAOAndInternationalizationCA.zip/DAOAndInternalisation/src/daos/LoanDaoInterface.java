/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package daos;

import business.Loan;
import java.util.List;

/**
 *
 * @author MELANIE WHO-AM-I
 */
public interface LoanDaoInterface {
     public List<Loan> getAllLoans();
    public List<Loan> detailsOfAllPreviousLoans(int userId);
    public List<Loan> getAllActiveLoans(int userID);
}
