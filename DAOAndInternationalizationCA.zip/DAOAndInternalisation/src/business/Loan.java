/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business;

import java.util.Locale;
import java.util.Objects;
import java.util.ResourceBundle;

/**
 *
 * @author waseema
 */
public class Loan {
      public static String BREAKING_CHAR = "%%";
    private static Locale locale = Locale.getDefault();
    private static ResourceBundle bundle = ResourceBundle.getBundle("Languages.LoanApp_en", locale);
    //private static NumberFormat numberFormatter = NumberFormat.getInstance(locale);
    
     public int loanID;
    public int userID;
    public int bookID;
    public String loan_date;
    public String due_date;
    public String status;

 

    public Loan(int loanID, int userID, int bookID, String loan_date, String due_date, String status) {
        this.loanID = loanID;
        this.userID = userID;
        this.bookID = bookID;
        this.loan_date = loan_date;
        this.due_date = due_date;
        this.status = status;
    }
    
    public int getloanID() {
        return loanID;
    }
    
    public int getUserID() {
        return userID;
    }

 

    public int getBookID() {
        return bookID;
    }

 

    public String getLoan_date() {
        return loan_date;
    }

 

    public String getDue_date() {
        return due_date;
    }

 

    public String getStatus() {
        return status;
    }

 

    public void setloanID(int loanID) {
        this.loanID = loanID;
    } 
    
    public void setUserID(int userID) {
        this.userID = userID;
    }

 

    public void setBookID(int bookID) {
        this.bookID = bookID;
    }

 

    public void setLoan_date(String loan_date) {
        this.loan_date = loan_date;
    }

 

    public void setDue_date(String due_date) {
        this.due_date = due_date;
    }

 

    public void setStatus(String status) {
        this.status = status;
    }

 

    @Override
    public String toString() {
        return "Loan{" + "loanID=" + loanID + "userID=" + userID + ", bookID=" + bookID + ", loan_date=" + loan_date + ", due_date=" + due_date + ", status=" + status + '}';
    }

 

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 41 * hash + this.loanID;
        hash = 41 * hash + this.userID;
        hash = 41 * hash + this.bookID;
        hash = 41 * hash + Objects.hashCode(this.loan_date);
        hash = 41 * hash + Objects.hashCode(this.due_date);
        hash = 41 * hash + Objects.hashCode(this.status);
        return hash;
    }

 

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Loan other = (Loan) obj;
        if (this.loanID != other.loanID) {
            return false;
        }
        if (this.userID != other.userID) {
            return false;
        }
        if (this.bookID != other.bookID) {
            return false;
        }
        if (!Objects.equals(this.loan_date, other.loan_date)) {
            return false;
        }
        if (!Objects.equals(this.due_date, other.due_date)) {
            return false;
        }
        if (!Objects.equals(this.status, other.status)) {
            return false;
        }
        return true;
    }
 public static void updateLocale(Locale l){
        locale = l;
        setBundle();
    }
    
    // Reset the resource bundle being used on Product objects
    // so that it uses the right language file
    private static void setBundle(){
        bundle = ResourceBundle.getBundle("languages.LoanApp_en", locale);
    }
    
    

 

     public String formatForStorage(){
        return loanID + BREAKING_CHAR + userID + BREAKING_CHAR + bookID + BREAKING_CHAR + loan_date + BREAKING_CHAR + due_date  + BREAKING_CHAR  + status;
    }
     

}
