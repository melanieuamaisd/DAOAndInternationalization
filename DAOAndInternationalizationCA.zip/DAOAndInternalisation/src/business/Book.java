/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business;

import java.text.NumberFormat;
import java.util.Locale;
import java.util.Objects;
import java.util.ResourceBundle;

/**
 *
 * @author MELANIE WHO-AM-I
 */
public class Book {
    public static String BREAKING_CHAR = "%%";
    private static Locale locale = Locale.getDefault();
    private static ResourceBundle bundle = ResourceBundle.getBundle("languages.BookApp_en", locale);
    //private static NumberFormat numberFormatter = NumberFormat.getInstance(locale);

    //variables are the same as the ones in the databse
    private int id;
    private String title;
    private String author;
    private int published;
    private int stock;
    public boolean isBorrowed;
    public boolean borrowed;

    public Book(int id, String title, String author, int published, int stock) {
        this.id = id;
        this.title = title;
        this.author = author;
        this.published = published;
        this.stock = stock;
    }

    //getters and setters (DTOs)
    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public int getPublished() {
        return published;
    }

    public int getStock() {
        return stock;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public void setPublished(int published) {
        this.published = published;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 53 * hash + this.id;
        hash = 53 * hash + Objects.hashCode(this.title);
        hash = 53 * hash + Objects.hashCode(this.author);
        hash = 53 * hash + this.published;
        hash = 53 * hash + this.stock;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Book other = (Book) obj;
        if (this.id != other.id) {
            return false;
        }
        if (this.published != other.published) {
            return false;
        }
        if (this.stock != other.stock) {
            return false;
        }
        if (!Objects.equals(this.title, other.title)) {
            return false;
        }
        if (!Objects.equals(this.author, other.author)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Book{" + "id=" + id + ", title=" + title + ", author=" + author + ", published=" + published + ", stock=" + stock + '}';
    }

    
   public static void updateLocale(Locale l){
        locale = l;
        setBundle();
    }
    
    // Reset the resource bundle being used on Product objects
    // so that it uses the right language file
    private static void setBundle(){
        bundle = ResourceBundle.getBundle("languages.BookApp_en", locale);
    }
    
    

     public String formatForStorage(){
        return id + BREAKING_CHAR + title + BREAKING_CHAR + author + BREAKING_CHAR + published + BREAKING_CHAR + stock;
    }
}
