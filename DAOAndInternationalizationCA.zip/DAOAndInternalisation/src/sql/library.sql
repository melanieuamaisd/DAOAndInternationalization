CREATE DATABASE IF NOT EXISTS `library` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `library`;
/*Table struture for addresses*/
DROP TABLE IF EXISTS `address`;
CREATE TABLE `address` (
  `addressId` int(11) NOT NULL,
  `first_line` varchar(250) NOT NULL,
  `second_line` varchar(250) NOT NULL,
  `county` varchar(250) NOT NULL,
  `eircode` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for books*/
DROP TABLE IF EXISTS `books`;
CREATE TABLE `books` (
  `bookID` int(10) NOT NULL,
  `title` varchar(50) NOT NULL,
  `author` varchar(50) NOT NULL,
  `published` date DEFAULT NULL,
  `stock` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

DROP TABLE IF EXISTS `genre_name`;
CREATE TABLE `genre_name` (
  `genreId` int(11) NOT NULL,
  `bookId` int(11) NOT NULL,
  `Fiction` varchar(250) NOT NULL,
  `Adventure` varchar(250) NOT NULL,
  `Romance` varchar(250) NOT NULL,
  `Horror` varchar(250) NOT NULL,
  `Comedy` varchar(250) NOT NULL,
  `Non_Fiction` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

DROP TABLE IF EXISTS `loan`;
CREATE TABLE `loan` (
  `userID` int(11) NOT NULL,
  `bookID` int(11) NOT NULL,
  `loan_Date` date DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `userID` int(11) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(20) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `phone_number` varchar(20) DEFAULT NULL,
  `book_limit` int(10) DEFAULT NULL,
  `user_status` varchar(50) DEFAULT NULL,
  `state` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT DELAYED INTO `books` (`bookID`, `title`, `author`, `published`, `stock`) VALUES
(1, 'The Girl With No Name', 'Lisa Regan', '2018-04-19', 10),
(2, 'A Doll\'s House', 'Henrik Ibsen', '2009-10-22', 15),
(3, 'Of Mice and Men', 'John Steinbeck', '1937-11-23', 20),
(4, 'The Great Gatsby', 'F.Scott Fitzgerald', '1925-04-10', 15),
(5, 'The Outsiders', 'S.E. Hinton', '1967-04-24', 18),
(6, 'The Cross and The Switchblade', 'David Wilkerson', '1963-06-17', 17),
(7, 'Holes', 'Louis Sachar', '1998-08-20', 10),
(8, 'Sive', 'John B Keane', '1959-05-01', 30),
(9, 'Percy Jackson and the lightning thief', 'Rick Riordan', '2005-06-28', 12),
(10, 'The Klone and I', 'Danielle Steel', '1998-06-01', 10),
(11, 'twilight Saga series', 'Stephanie Meyer', '2011-04-12', 2),
(12, 'In Search of lost time', 'Marcel Proust', '1913-01-01', 10),
(14, 'Harry Potter , deathly hallows', 'J.K Rowling', '2007-07-21', 1),
(15, 'Boy', 'Roald Dahl', '1984-06-17', 1);


INSERT DELAYED INTO `loan` (`userID`, `bookID`, `loan_Date`, `due_date`, `status`) VALUES
(1000, 1, '2020-10-26', '2020-10-26', 'active'),
(1001, 1, '2000-03-16', '2000-04-15', 'closed'),
(1002, 2, '2001-12-20', '2001-01-23', 'closed'),
(1003, 3, '2020-05-10', '2020-07-21', 'closed'),
(1004, 4, '2020-05-24', '2020-06-23', 'closed'),
(1005, 5, '2020-03-26', '2020-05-12', 'active'),
(1006, 6, '2018-02-13', '2019-04-22', 'closed'),
(1007, 7, '2020-09-13', '2020-10-02', 'active'),
(1008, 8, '2020-05-22', '2020-07-13', 'active'),
(1009, 9, '2020-10-26', '2020-11-09', 'active'),
(1010, 10, '2020-10-26', '2020-11-09', 'active'),
(1011, 11, '2020-10-31', '2020-11-14', 'active'),
(1012, 12, '2020-10-31', '2020-11-14', 'active'),
(1013, 13, '2020-11-05', '2020-11-19', 'closed'),
(1016, 11, '2020-11-05', '2020-11-19', 'active');

INSERT DELAYED INTO `users` (`userID`, `username`, `password`, `firstname`, `lastname`, `phone_number`, `book_limit`, `user_status`, `state`) VALUES
(1001, 'melanie44', 'tantan', 'melanie', 'uamai', '89123456', 1, 'member', 1),
(1002, 'chrisboss44', 'staten23', 'christian', 'cobliada', '872468012', 1, 'admin', 1),
(1003, 'waseema12', 'wasssup33', 'waseema', 'parhiar', '865622744', 1, 'member', 1),
(1004, 'jonnyboy45', 'holyjohn87', 'john', 'smith', '891985643', 1, 'admin', 0),
(1005, 'marieanne48', 'annemarie45', 'anne marie', 'winters', '867834676', 2, 'member', 1),
(1006, 'Diane58', 'dmurphyx500', 'Diane', 'Murphy', '0873427596', 1, 'member', 1),
(1007, 'Jeff97', 'jeffx2973', 'Jeffrey', 'Anthony', '0864925670', 2, 'admin', 0),
(1008, 'Larry2311', 'larrzBott', 'Larry', 'Bott', '0834644873', 2, 'admin', 1),
(1009, 'MaryPatterson', 'maryX4611', 'Mary', 'Patterson', '0846789010', 1, 'admin', 1),
(1010, 'LouisBon', 'BonnNuitx45', 'Louis', 'Bonn', '0832311102', 1, 'member', 0),
(1011, 'MartinX', 'MiniWheels', 'Martin', 'Gerard', '0834032555', 2, 'member', 0);


