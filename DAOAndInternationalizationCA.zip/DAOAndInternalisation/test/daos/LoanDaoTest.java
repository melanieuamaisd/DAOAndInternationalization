/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package daos;

import business.Loan;
import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author waseema
 */
public class LoanDaoTest {
    private static LoanDao lDao;
    public LoanDaoTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
         lDao = new LoanDao("library");
    }
    
    /**
     * Test of getAllActiveLoans method, of class LoanDao.
     */

@Test  
public void testGetAllActiveLoans() {
       
     

 

 int numActiveLoansInTable = 1;

 


 List<Loan> result = lDao.getAllActiveLoans(1001);

 

 // Check that the number of entries retrieved matches the (known) size of

 

 // the test database's table

 

 assertEquals(numActiveLoansInTable, result.size());
}

 

   
/**
     * Test of getAllActiveLoans method, of class LoanDao.
     */
@Test  
public void detailsOfAllPreviousLoans() {
       
     

 

 int numPreviousLoansInTable = 1;

 


 List<Loan> result = lDao.detailsOfAllPreviousLoans(1001);

 

 // Check that the number of entries retrieved matches the (known) size of

 

 // the test database's table

 

 assertEquals(numPreviousLoansInTable, result.size());
}
@Test
public void testGetAllLoans() {
        
        int numLoansInTable = 6;
        
        List<Loan> result = lDao.getAllLoans();
        // Check that the number of entries retrieved matches the (known) size of 
        // the test database's table
        
        // An alternative approach could be to create a full arraylist of the expected
        // Product results. It is a more accurate test but is more time-consuming.
       assertEquals(numLoansInTable, result.size());
    }
}
