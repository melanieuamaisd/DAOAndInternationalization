/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package daos;

import business.Book;
import daos.BookDao;
import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author MELANIE WHO-AM-I
 */
public class BookDaoTest {
   private static BookDao bkDao;
   public  BookDaoTest()
   {
       
   }
   
  @BeforeClass
  public static void setUpClass()
  {
      bkDao = new BookDao("library");
  }
  
  /**
   * Test gatAllBooks method of BookDao
   */
  @Test
  public void testGetAllBooks()
  {
  int numBooksInTable = 14;
  
  List<Book> result = bkDao.getAllBooks();
   // Check that the number of entries retrieved matches the (known) size of 
  // the test database's table
  assertEquals(numBooksInTable, result.size());
  }
  
  @Test 
  public void testGetBookByTitle(){
      String title = "Holes";
      //make book that matches the book in the database
      Book expResult = new Book(7,"Holes","Louis Sachar",1998,10);
      //get book from databse
      Book result = bkDao.getBookByTitle(title);
      //confirmation that they are the same
      assertEquals(expResult, result);
  }
  
  /**
   * Test of getBookByTitle where a book doesn't exist
   */
  @Test
  public void testGetBookByTitleWhereNotExisting(){
      String title = "Tracy Beaker";
      Book expResult = null;
      Book result = bkDao.getBookByTitle(title);
      assertEquals(expResult, result);
  }
  
  /**
   * Test addBook method
   */
  
  @Test
  public void testAddBook(){
      int bookID = 16;
      String title = "Tracy Beaker";
      String author = "Jacqueline Wilson";
      int published = 2006-10-05;
      int stock = 1;
      
      boolean expResult = true;
      boolean result = bkDao.addBook(bookID, title, author, author, stock);
  }
  
  @Test 
  public void borrowBook()
  {
      String title = "Twilight saga series";
      String author = "stephanie meyer";
      int userId = 1014;
      
      
      
  }
}
